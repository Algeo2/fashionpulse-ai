"""Runs without access to training data or the original image directory."""
import base64
import json
from pathlib import Path
import unittest
import numpy as np
from handler import handler

ROOT = Path(__file__).resolve().parent


def request(method,path,payload=None,**kwargs):
    event = {'requestContext':{'http':{'method':method}},'rawPath':path,
        'headers':{'content-type':'application/json'},'body':json.dumps(payload)}
    event.update(kwargs)
    return handler(event,None)


class BundleTests(unittest.TestCase):
    def test_predictions_match_sealed_models(self):
        metadata = json.loads(request('GET','/api/metadata')['body'])
        expected = json.loads((ROOT/'runtime/expected.json').read_text(encoding='utf-8'))
        for objective in metadata['choices']:
            payload = dict(metadata['example'],objective=objective)
            if metadata['image_required'][objective]:
                payload['image_base64'] = base64.b64encode((ROOT/'runtime/example.png').read_bytes()).decode('ascii')
            result = request('POST','/api/predict',payload)
            self.assertEqual(result['statusCode'],200,result)
            actual = json.loads(result['body'])
            np.testing.assert_allclose([w['units'] for w in actual['forecast']],
                [w['units'] for w in expected[objective]['forecast']],atol=1e-7,rtol=1e-7)

    def test_invalid_requests(self):
        self.assertEqual(request('POST','/api/predict',headers={'content-type':'text/plain'})['statusCode'],415)
        self.assertEqual(request('POST','/api/predict',body='NaN')['statusCode'],400)
        self.assertEqual(request('POST','/api/predict',body='x'*4_100_001)['statusCode'],413)
        self.assertEqual(request('GET','/runtime/manifest.json')['statusCode'],404)
        self.assertEqual(request('DELETE','/api/predict')['statusCode'],404)
        self.assertEqual(request('POST','/api/predict',body='%%%!',isBase64Encoded=True)['statusCode'],400)

    def test_metadata_evaluation_and_image(self):
        for path in ['/api/metadata','/api/evaluation','/api/health','/api/example-image']:
            self.assertEqual(request('GET',path)['statusCode'],200,path)
        result = request('GET','/api/example-image')
        self.assertEqual(base64.b64decode(result['body']),(ROOT/'runtime/example.png').read_bytes())


if __name__ == '__main__':
    unittest.main()
