"""Lambda Function URL v2 adapter. AWS_IAM authentication is configured externally."""
import base64
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'work/fashionpulse_service'))
MAX_BODY = 4_100_000
_predictor = None


def predictor():
    global _predictor
    if _predictor is None:
        manifest = json.loads((ROOT/'runtime/manifest.json').read_text(encoding='utf-8'))
        for relative, expected in manifest['sha256'].items():
            path = (ROOT/relative).resolve()
            if not path.is_relative_to(ROOT) or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
                raise RuntimeError('Runtime integrity check failed')
        from service import Predictor
        _predictor = Predictor()
    return _predictor


def response(status, body, content_type='application/json; charset=utf-8', binary=False):
    if binary:
        body = base64.b64encode(body).decode('ascii')
    else:
        body = json.dumps(body, ensure_ascii=False, allow_nan=False)
    return {'statusCode': status, 'headers': {'content-type':content_type,
        'cache-control':'no-store', 'x-content-type-options':'nosniff'},
        'isBase64Encoded':binary, 'body':body}


def reject_constant(value):
    raise ValueError('Número JSON no válido.')


def handler(event, context):
    method = event.get('requestContext',{}).get('http',{}).get('method')
    path = event.get('rawPath','')
    try:
        if method == 'GET':
            if path == '/api/health':
                predictor()
                return response(200, {'status':'ok','mode':'cloud','model_loaded':True})
            if path == '/api/metadata':
                return response(200, predictor().metadata())
            if path == '/api/evaluation':
                return response(200,json.loads((ROOT/'runtime/evaluation.json').read_text(encoding='utf-8')))
            if path == '/api/example-image':
                return response(200,predictor().example_image.read_bytes(),'image/png',True)
        if path == '/api/predict' and method == 'POST':
            headers = {k.lower():v for k,v in event.get('headers',{}).items()}
            if headers.get('content-type','').split(';')[0].strip() != 'application/json':
                return response(415, {'error':'Usa application/json.'})
            body = event.get('body') or ''
            if not isinstance(body,str) or len(body)>MAX_BODY:
                return response(413, {'error':'Solicitud demasiado grande; usa una foto de hasta 3 MB.'})
            raw = base64.b64decode(body,validate=True) if event.get('isBase64Encoded') else body.encode('utf-8')
            if not raw or len(raw)>MAX_BODY:
                return response(413, {'error':'Solicitud vacía o demasiado grande.'})
            payload = json.loads(raw.decode('utf-8'), parse_constant=reject_constant)
            return response(200, predictor().predict(payload))
        return response(404, {'error':'No encontrado.'})
    except (ValueError, UnicodeError) as exc:
        return response(400, {'error':str(exc)})
    except Exception:
        # Do not log images, payloads or credentials.
        return response(500, {'error':'No se pudo generar el pronóstico.'})
