# FashionPulse AI: paquete local independiente

Este paquete contiene la aplicación, los dos modelos evaluados y el encoder de imágenes. No necesita la carpeta VISUELLE2 original ni las particiones de entrenamiento para funcionar. El procesamiento ocurre en tu computador, sin llamadas a AWS ni APIs de inferencia.

Necesita Python 3.11 con las bibliotecas de `requirements.txt` y PyTorch CPU 2.5.1 / torchvision CPU 0.20.1. El ZIP no incluye el intérprete ni el entorno de Python. En el computador del proyecto, usa **IniciarFashionPulseLocal.cmd**, en la raíz del proyecto: reutiliza el entorno ya instalado.

En otro computador, descomprime el ZIP, crea un entorno Python 3.11 e instala las dependencias (la instalación inicial requiere Internet):

```powershell
py -3.11 -m venv .venv
& ./.venv/Scripts/python.exe -m pip install torch==2.5.1+cpu torchvision==0.20.1+cpu --index-url https://download.pytorch.org/whl/cpu
& ./.venv/Scripts/python.exe -m pip install -r requirements.txt
& ./.venv/Scripts/python.exe work/fashionpulse_service/server.py --port 8765
```

Abre http://127.0.0.1:8765/#analizar. Mantén la terminal abierta y usa Ctrl+C para detener el servidor. Solo escucha en este computador.

1. Pulsa **Cargar ejemplo histórico**.
2. Elige el objetivo: error semanal o volumen total.
3. Pulsa **Generar pronóstico**. El modelo de volumen requiere la fotografía; el semanal utiliza la categoría.
4. Consulta las 12 semanas o descarga el CSV.
5. En **Acerca del modelo** están la comparación temporal y la prueba final de 2019.

Las fotos se procesan en memoria y no se guardan. El ejemplo produce 12 unidades con la mediana y aproximadamente 12,93 unidades con el modelo visual. Estos valores son una comprobación reproducible, no una promesa comercial. Inicio, catálogo y tendencias conservan datos de demostración.

La aplicación comprueba la integridad de los archivos del paquete. No edites los checkpoints ni los archivos sellados dentro de este directorio: regenera el paquete desde el código del proyecto. El manifiesto detecta cambios accidentales; no es una firma criptográfica que autentique un distribuidor. Los modelos joblib deben proceder de una fuente de confianza.

Los datos son históricos y no validan predicciones para una tienda colombiana actual. La prueba final de 2019 ya fue utilizada. Este paquete no reentrena modelos ni genera cargos de alojamiento.
