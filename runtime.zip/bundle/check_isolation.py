"""Block access to original datasets/artifacts, then exercise both real forecasts."""
import argparse
import base64
import json
import os
from pathlib import Path
import sys


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--project-root',required=True,type=Path)
    parser.add_argument('--dataset-root',required=True,type=Path)
    args=parser.parse_args()
    blocked=[args.dataset_root.resolve()]
    blocked += [(args.project_root/'outputs'/name).resolve() for name in [
        'visuelle_particiones','visuelle_baseline','visuelle_embeddings','visuelle_backtest']]
    bundle=Path(__file__).resolve().parent
    if any(bundle.is_relative_to(path) for path in blocked): raise ValueError('Bundle overlaps prohibited inputs')
    def audit(event,values):
        if event!='open' or not isinstance(values[0],(str,bytes,os.PathLike)): return
        path=Path(os.fsdecode(values[0])).resolve()
        if any(path.is_relative_to(root) for root in blocked):
            raise PermissionError('Original dataset/artifact access is forbidden in isolation test')
    sys.addaudithook(audit)
    sys.path.insert(0,str(bundle/'work/fashionpulse_service'))
    from service import Predictor
    model=Predictor()
    expected=json.loads((bundle/'runtime/expected.json').read_text(encoding='utf-8'))
    import numpy as np
    totals={}
    for objective in model.selection['choices']:
        payload=dict(model.example,objective=objective)
        if model.metadata()['image_required'][objective]:
            payload['image_base64']=base64.b64encode(model.example_image.read_bytes()).decode('ascii')
        result=model.predict(payload)
        np.testing.assert_allclose([w['units'] for w in result['forecast']],
            [w['units'] for w in expected[objective]['forecast']],rtol=1e-7,atol=1e-7)
        totals[objective]=result['total_12weeks']
    print(json.dumps({'status':'passed','original_inputs_blocked':True,'totals':totals}))


if __name__=='__main__':
    main()
