"""Frozen HF ResNet18, safe weights, one embedding per train/validation image."""
import argparse
import json
import os
import time
from pathlib import Path
from datetime import datetime, timezone
from common import OUT, RAW, ROOT, sha, save_json, load_frame, product_manifest

os.environ['HF_HOME'] = str(OUT / 'hf_cache')
os.environ['HF_HUB_DISABLE_TELEMETRY'] = '1'
os.environ['HF_HUB_DISABLE_XET'] = '1'
os.environ['HF_HUB_DISABLE_SYMLINKS_WARNING'] = '1'

import numpy as np
import torch
import timm
from PIL import Image, ImageOps
from huggingface_hub import HfApi, hf_hub_download
from safetensors.torch import load_file

REPO = 'timm/resnet18.a1_in1k'

def encoder_from_files(weights, config):
    cfg = json.loads(Path(config).read_text())
    model = timm.create_model(cfg['architecture'], pretrained=False,
        num_classes=cfg['num_classes'], pretrained_cfg=cfg['pretrained_cfg'])
    model.load_state_dict(load_file(str(weights), device='cpu'), strict=True)
    model.reset_classifier(0)
    model.eval().requires_grad_(False)
    data_cfg = timm.data.resolve_model_data_config(model)
    transform = timm.data.create_transform(**data_cfg, is_training=False)
    return model, transform, data_cfg

def encode_paths(paths, model, transform, batch_size=16):
    result = []
    with torch.inference_mode():
        for start in range(0, len(paths), batch_size):
            batch = []
            for path in paths[start:start+batch_size]:
                with Image.open(path) as image:
                    batch.append(transform(ImageOps.exif_transpose(image).convert('RGB')))
            vectors = model(torch.stack(batch)).cpu().numpy()
            if vectors.shape != (len(batch), 512) or not np.isfinite(vectors).all():
                raise ValueError('Invalid encoder output')
            result.append(vectors)
            if start == 0 or (start // batch_size) % 10 == 0:
                print(f'Encoded {start+len(batch)}/{len(paths)} images', flush=True)
    return np.concatenate(result).astype(np.float32)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--image-root', type=Path, default=RAW)
    parser.add_argument('--revision', help='Optional exact Hugging Face commit')
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    protocol = {
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'encoder': REPO, 'encoder_training': 'External ImageNet-1k pretrained; frozen, no fine tuning',
        'embeddings': 512, 'normalization': 'Per-image L2, no fitted population statistics',
        'pca_components': 32, 'pca_fit': 'Unique training products only; no validation images in fit',
        'regressor': 'ExtraTrees, 96 trees, depth 14, leaf 20, max_features .75, seed 42, 4 threads',
        'matched_control': 'Existing metadata-only extra_trees_leaf20, verify inputs and predictions',
        'primary_metric': 'Validation MAE across identical product-shop-week cells',
        'primary_variant': 'A retains negatives', 'sensitivity_variant': 'B clips targets at zero',
        'search_budget': 'One visual encoder and one PCA dimension, fixed before scoring',
        'test_policy': 'Do not open test.csv or encode test images',
        'bootstrap': '2000 paired product-cluster resamples; descriptive 95% interval of micro MAE difference; seed 42',
        'feature_sampling_note': 'Same .75 fraction with more columns changes the absolute number of split candidates',
    }
    save_json(OUT / 'protocol.json', protocol)
    train, val = load_frame('A', 'train'), load_frame('A', 'validation')
    manifest = product_manifest(train, val)
    image_root = args.image_root.resolve()
    paths = [(image_root / p).resolve() for p in manifest.image_path]
    if any(not p.is_relative_to(image_root) for p in paths):
        raise ValueError('Image path escapes image root')
    manifest['sha256'] = [sha(p) for p in paths]
    revision = args.revision or HfApi().model_info(REPO).sha
    config = hf_hub_download(REPO, 'config.json', revision=revision)
    weights = hf_hub_download(REPO, 'model.safetensors', revision=revision)
    torch.set_num_threads(4)
    torch.manual_seed(42)
    model, transform, data_cfg = encoder_from_files(weights, config)
    start = time.perf_counter()
    vectors = encode_paths(paths, model, transform)
    np.save(OUT / 'embeddings.npy', vectors, allow_pickle=False)
    manifest.to_csv(OUT / 'image_manifest.csv', index=False)
    save_json(OUT / 'encoder.json', {
        'repository': REPO, 'revision': revision,
        'weights': str(Path(weights).relative_to(OUT)), 'weights_sha256': sha(weights),
        'config': str(Path(config).relative_to(OUT)), 'config_sha256': sha(config),
        'embeddings_sha256': sha(OUT / 'embeddings.npy'),
        'manifest_sha256': sha(OUT / 'image_manifest.csv'),
        'data_config': data_cfg, 'transform': str(transform),
        'exif_orientation': 'ImageOps.exif_transpose before RGB conversion',
        'torch': torch.__version__, 'timm': timm.__version__, 'device': 'cpu',
        'shape': list(vectors.shape), 'train_products': int((manifest.split == 'train').sum()),
        'validation_products': int((manifest.split == 'validation').sum()),
        'seconds': time.perf_counter() - start, 'test_opened': False,
    })
    print(f'Finished extraction: {vectors.shape}', flush=True)

if __name__ == '__main__':
    main()
