"""Persistable metadata + frozen visual feature model. No raw labels in features."""
import numpy as np
from sklearn.decomposition import PCA
from sklearn.base import clone
from common import normalize

def fit_projection(vectors, manifest, components=32):
    if manifest.external_code.duplicated().any() or len(vectors) != len(manifest):
        raise ValueError('PCA needs exactly one embedding per product')
    mask = manifest.split.eq('train').to_numpy()
    if not mask.any() or not set(manifest.split).issubset({'train', 'validation'}):
        raise ValueError('Invalid PCA partitions')
    projection = PCA(n_components=components, svd_solver='full')
    projection.fit(normalize(vectors[mask]))
    projection.training_product_ids_ = manifest.loc[mask, 'external_code'].astype(str).tolist()
    return projection

class VisualRegressor:
    def __init__(self, metadata, projection, estimator):
        self.metadata = metadata
        self.projection = projection
        self.estimator = clone(estimator)

    def features(self, X, embeddings):
        if len(X) != len(embeddings):
            raise ValueError('One embedding required for each product-shop row')
        return np.column_stack((self.metadata.transform(X),
            self.projection.transform(normalize(embeddings)))).astype(np.float32)

    def fit(self, X, embeddings, y):
        self.estimator.fit(self.features(X, embeddings), y)
        return self

    def predict(self, X, embeddings):
        return self.estimator.predict(self.features(X, embeddings))
