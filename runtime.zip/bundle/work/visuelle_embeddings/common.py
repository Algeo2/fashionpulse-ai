"""Shared, test-blind experiment paths and validation."""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'work/visuelle_baseline'))
from baseline_models import TARGETS, FEATURE_INPUTS, make_model, metrics

OUT = ROOT / 'outputs/visuelle_embeddings'
RAW = Path('C:/Users/dhurt/OneDrive/Escritorio/Carpetas/UNI/Big Data/FashionPulse/visuelle2/visuelle2/images')
KEY = ['external_code', 'retail']

def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def save_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False,
        default=lambda x: x.item() if hasattr(x, 'item') else str(x)), encoding='utf-8')

def load_frame(variant, split):
    if variant not in {'A', 'B'} or split not in {'train', 'validation'}:
        raise ValueError('Only train/validation permitted; final test is reserved')
    path = ROOT / 'outputs/visuelle_particiones' / variant / (split + '.csv')
    previous = json.loads((ROOT / 'outputs/visuelle_baseline/results.json').read_text())
    relative = str(path.relative_to(ROOT))
    if sha(path) != previous['inputs_opened_sha256'][relative]:
        raise ValueError('Partition differs from original baseline: ' + relative)
    frame = pd.read_csv(path, dtype={k: 'string' for k in KEY})
    if frame.duplicated(KEY).any() or frame[FEATURE_INPUTS + TARGETS + ['image_path']].isna().any().any():
        raise ValueError('Duplicate keys or missing inputs')
    return frame

def product_manifest(train, val):
    if not set(train.external_code).isdisjoint(val.external_code):
        raise ValueError('Product leakage')
    if pd.to_datetime(train.release_date).max() + pd.Timedelta(days=84) > pd.to_datetime(val.release_date).min():
        raise ValueError('Overlapping label windows')
    frames = []
    for split, frame in [('train', train), ('validation', val)]:
        products = frame[['external_code', 'image_path']].drop_duplicates()
        if products.external_code.duplicated().any():
            raise ValueError('Multiple images per product')
        frames.append(products.assign(split=split))
    return pd.concat(frames, ignore_index=True)

def align_embeddings(frame, manifest, embeddings):
    if manifest.external_code.duplicated().any() or len(manifest) != len(embeddings):
        raise ValueError('Invalid embedding manifest')
    index = pd.Index(manifest.external_code.astype(str)).get_indexer(frame.external_code.astype(str))
    if (index < 0).any():
        raise ValueError('Missing product embeddings')
    if not np.array_equal(manifest.image_path.to_numpy()[index], frame.image_path.to_numpy()):
        raise ValueError('Image path mismatch')
    return embeddings[index]

def normalize(vectors):
    vectors = np.asarray(vectors, dtype=np.float32)
    if vectors.ndim != 2 or not np.isfinite(vectors).all():
        raise ValueError('Invalid image vectors')
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    if (norms <= 0).any():
        raise ValueError('Zero image vector')
    return vectors / norms
