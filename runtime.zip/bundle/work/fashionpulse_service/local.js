/* Local adapter: preserves the hosted prototype and replaces only local analysis. */
(() => {
  const $ = id => document.getElementById(id);
  const escape = value => String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const number = value => Number(value).toLocaleString('es-CO',{maximumFractionDigits:2});
  const metric = value => Number(value).toLocaleString('es-CO',{minimumFractionDigits:4,maximumFractionDigits:4});
  const labels = {category_median:'Mediana por categoría',extra_trees_leaf20:'Árboles con metadatos',extra_trees_images_pca32:'Árboles con imágenes'};
  const oldForm=$('analysisForm');
  const form=oldForm.cloneNode(false);
  oldForm.replaceWith(form);
  form.innerHTML='<p role="status">Conectando con el modelo local…</p>';
  const result=document.querySelector('#analizar .result-panel');
  result.removeAttribute('aria-labelledby');
  result.setAttribute('aria-label','Resultado del pronóstico');
  result.innerHTML='<h2>Pronóstico de ventas</h2><p class="forecast-note">Configura una prenda para estimar sus primeras 12 semanas.</p>';
  document.querySelector('#analizar .page-heading h1').textContent='Pronosticar una nueva prenda';
  document.querySelector('#analizar .page-heading .eyebrow').textContent='Inferencia del modelo';
  document.querySelector('#analizar .page-heading .lead').textContent='Predicción real de 12 semanas con modelos evaluados sobre VISUELLE2.';
  const banner=document.createElement('aside');
  banner.className='local-banner';
  banner.innerHTML='<strong>FashionPulse · Modelo local conectado</strong>El análisis usa predicciones reales. Inicio, productos y tendencias conservan datos de demostración.';
  document.querySelector('.workspace').prepend(banner);
  let metadata, lastResult, currentImage=null, previewURL=null;

  async function api(path,options) {
    const response=await fetch(path,options);
    const body=await response.json();
    if(!response.ok) throw new Error(body.error || 'No se pudo completar la solicitud.');
    return body;
  }
  function selectField(name,label,values) {
    return `<label class="field"><span>${label}</span><select name="${name}" id="real-${name}" required>${values.map(x=>`<option value="${escape(x)}">${escape(x)}</option>`).join('')}</select></label>`;
  }
  function updateObjective() {
    const objective=$('real-objective').value;
    const model=metadata.choices[objective];
    $('real-model-note').textContent=model==='category_median'
      ? 'Este modelo utiliza solo la categoría. Los demás datos permiten comparar con el modelo de volumen.'
      : 'Este modelo utiliza los metadatos y '+(metadata.image_required[objective]?'la fotografía de la prenda.':'no utiliza la fotografía.');
    $('real-image').required=metadata.image_required[objective];
    $('real-image-note').textContent=metadata.image_required[objective]
      ? 'Foto requerida: PNG/JPEG, máximo 8 MB y 12 megapíxeles. Se procesa en este computador.'
      : 'Foto opcional de referencia. No interviene en este pronóstico.';
  }
  function fillExample() {
    for(const key of ['category','color','fabric','retail','release_date']) $('real-'+key).value=metadata.example[key];
    $('real-season').value=metadata.example.season.slice(0,2);
  }
  async function load() {
    try {
      metadata=await api('/api/metadata');
      form.innerHTML=`<label class="field"><span>Qué quieres estimar</span><select name="objective" id="real-objective"><option value="weekly_mae">Error semanal: modelo con menor MAE histórico</option><option value="total_12weeks">Volumen: modelo con menor error total histórico</option></select></label>
        <p class="forecast-note" id="real-model-note"></p><div class="form-grid">
        ${selectField('category','Categoría (etiqueta del dataset)',metadata.options.category)}
        ${selectField('color','Color',metadata.options.color)}
        ${selectField('fabric','Tejido / acabado',metadata.options.fabric)}
        ${selectField('retail','Tienda de referencia VISUELLE2',metadata.options.retail)}
        <label class="field"><span>Fecha de lanzamiento</span><input type="date" name="release_date" id="real-release_date" min="2016-01-01" max="2100-12-31" required></label>
        <label class="field"><span>Colección</span><select name="collection" id="real-season"><option value="SS">Primavera / verano (SS)</option><option value="AW">Otoño / invierno (AW)</option></select></label></div>
        <label class="field"><span>Foto de la prenda</span><input type="file" id="real-image" accept="image/png,image/jpeg"></label>
        <p class="forecast-note" id="real-image-note"></p><img id="real-preview" class="forecast-preview" alt="Vista previa de la prenda" hidden>
        <div class="forecast-actions"><button type="button" class="ghost-action" id="real-example">Cargar ejemplo histórico</button><button class="primary-action" type="submit" id="real-submit">Generar pronóstico</button></div>
        <p class="forecast-note">Modelo académico entrenado con datos anteriores a julio de 2018. El precio y el público objetivo no son entradas del modelo. La estimación no representa una probabilidad de éxito comercial.</p>`;
      fillExample(); updateObjective();
      $('real-objective').addEventListener('change',updateObjective);
      $('real-example').addEventListener('click',async()=>{
        fillExample();
        try {
          const response=await fetch('/api/example-image');
          if(!response.ok) throw new Error('No se pudo cargar la foto del ejemplo.');
          currentImage=new File([await response.blob()],'ejemplo-visuelle.png',{type:'image/png'});
          const files=new DataTransfer(); files.items.add(currentImage); $('real-image').files=files.files;
          if(previewURL) URL.revokeObjectURL(previewURL);
          previewURL=URL.createObjectURL(currentImage);
          $('real-preview').src=previewURL; $('real-preview').hidden=false;
        } catch(error) { $('real-image-note').textContent=error.message; }
      });
      $('real-image').addEventListener('change',()=>{
        currentImage=$('real-image').files[0] || null;
        if(previewURL) URL.revokeObjectURL(previewURL);
        $('real-preview').hidden=!currentImage;
        if(currentImage) { previewURL=URL.createObjectURL(currentImage); $('real-preview').src=previewURL; }
      });
      form.addEventListener('submit',submit);
      const evaluation=await api('/api/evaluation');
      renderModel(evaluation);
    } catch(error) {
      form.innerHTML=`<p class="forecast-error" role="alert">${escape(error.message)} No se generarán resultados simulados.</p>`;
    }
  }
  function asBase64(file) {
    return new Promise((resolve,reject)=>{
      const reader=new FileReader();
      reader.onload=()=>resolve(String(reader.result).split(',')[1]);
      reader.onerror=()=>reject(new Error('No se pudo leer la fotografía.'));
      reader.readAsDataURL(file);
    });
  }
  async function submit(event) {
    event.preventDefault();
    $('real-submit').disabled=true;
    result.innerHTML='<p role="status">Calculando las 12 semanas…</p>';
    try {
      const data=new FormData(form);
      const payload=Object.fromEntries(['category','color','fabric','retail','release_date','objective'].map(k=>[k,data.get(k)]));
      payload.season=data.get('collection')+payload.release_date.slice(2,4);
      if(metadata.image_required[payload.objective]) {
        if(!currentImage || currentImage.size>8000000) throw new Error('Selecciona una fotografía de hasta 8 MB.');
        payload.image_base64=await asBase64(currentImage);
      }
      lastResult=await api('/api/predict',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
      renderResult(lastResult);
    } catch(error) {
      result.innerHTML=`<h2>No se pudo pronosticar</h2><p class="forecast-error" role="alert">${escape(error.message)}</p>`;
    } finally { $('real-submit').disabled=false; }
  }
  function renderResult(data) {
    const max=Math.max(1,...data.forecast.map(x=>Math.abs(x.units)));
    result.innerHTML=`<p class="eyebrow">Pronóstico real · 12 semanas</p><h2>${escape(labels[data.model] || data.model)}</h2>
      <p class="forecast-total">${number(data.total_12weeks)} <small>unidades</small></p>
      <p class="forecast-note">Suma de las 12 estimaciones semanales. ${data.image_used?'Incluye información de la fotografía.':'Sin información de la fotografía.'}</p>
      ${data.warnings.map(w=>`<p class="forecast-error">${escape(w)}</p>`).join('')}
      ${data.forecast.every(x=>x.units>=0)?`<div class="forecast-chart" aria-label="Pronóstico semanal, valores exactos en la tabla">${data.forecast.map(x=>`<div class="forecast-bar"><i style="height:${100*x.units/max}%"></i><span>S${x.week}</span></div>`).join('')}</div>`:''}
      <div class="forecast-scroll"><table class="forecast-table"><thead><tr><th>Semana</th><th>Desde</th><th>Unidades</th></tr></thead><tbody>${data.forecast.map(x=>`<tr><td>${x.week}</td><td>${escape(x.start_date)}</td><td>${number(x.units)}</td></tr>`).join('')}</tbody></table></div>
      <div class="forecast-actions"><button id="real-download" class="ghost-action" type="button">Descargar pronóstico CSV</button></div>
      <p class="forecast-note">${escape(data.scope)}</p>`;
    $('real-download').addEventListener('click',()=>{
      const csv='semana,fecha_inicio,fecha_fin,unidades\n'+data.forecast.map(x=>[x.week,x.start_date,x.end_date,x.units].join(',')).join('\n');
      const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));
      const anchor=document.createElement('a'); anchor.href=url; anchor.download='fashionpulse-pronostico.csv'; anchor.click();
      setTimeout(()=>URL.revokeObjectURL(url),1000);
    });
  }
  function renderModel(evaluation) {
    const rows=evaluation.historical.filter(x=>x.variant==='A');
    const final=evaluation.final.filter(x=>x.variant==='A');
    const table=data=>`<div class="forecast-scroll"><table class="forecast-table forecast-model-table"><thead><tr><th>Modelo</th><th>MAE semanal ↓</th><th>Error total 12 semanas ↓</th><th>Sesgo de volumen</th></tr></thead><tbody>${data.map(x=>`<tr><td>${escape(labels[x.model])}</td><td>${metric(x.mae)}</td><td>${metric(x.mae_total_12weeks)}</td><td>${number(x.volume_bias_pct)}%</td></tr>`).join('')}</tbody></table></div>`;
    $('modelo').innerHTML=`<div class="page-heading"><div><p class="eyebrow">Evidencia del experimento</p><h1>Acerca del modelo</h1><p class="lead">Comparación temporal y evaluación final con datos históricos.</p></div></div>
      <section class="panel"><h2>Validación: tres periodos de 2017–2018</h2><p class="forecast-note">Promedio de métricas por periodo, con el mismo peso para cada uno. A conserva los valores negativos originales. Menor error es mejor.</p>${table(rows)}
      <div class="forecast-meta"><h3>Prueba final: productos de 2019</h3><p class="forecast-note">Modelos elegidos antes de consultar estas ventas. Se mantuvo el entrenamiento original anterior a julio de 2018.</p>${table(final)}</div>
      <p class="forecast-note">La mediana y los árboles responden a objetivos distintos. Un menor MAE semanal no garantiza una buena estimación del volumen total. Las imágenes se evaluaron con ResNet18 congelado y PCA ajustado solo en entrenamiento.</p>
      <p class="forecast-note">Alcance: VISUELLE2 histórico, prendas y tiendas representadas en el dataset. No validado para el mercado colombiano actual. No se calcula probabilidad de éxito, efecto del precio ni retorno de una promoción.</p></section>`;
  }
  load();
})();
