"""Local academic inference service using sealed checkpoints only."""
from pathlib import Path
import sys
import json
import base64
import io
import re
from datetime import date,timedelta
import threading
import os
import joblib
import numpy as np
import pandas as pd
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/visuelle_embeddings'))
from common import sha, FEATURE_INPUTS, load_frame, RAW

class Predictor:
    def __init__(self):
        if (ROOT/'runtime/metadata.json').exists():
            manifest = json.loads((ROOT/'runtime/manifest.json').read_text(encoding='utf-8'))
            for relative, expected in manifest['sha256'].items():
                path = (ROOT/relative).resolve()
                if not path.is_relative_to(ROOT) or sha(path) != expected:
                    raise ValueError('Portable runtime checksum mismatch')
        output = ROOT/'outputs/visuelle_backtest'
        self.selection = json.loads((output/'selection.json').read_text(encoding='utf-8'))
        self.final = json.loads((output/'final_test.json').read_text(encoding='utf-8'))
        if sha(output/'selection.json') != self.final['selection_sha256_before_test']:
            raise ValueError('Selection was changed after final evaluation')
        self.models = {}
        for name in set(self.selection['choices'].values()):
            artifact = self.selection['checkpoints'][f'A_{name}']
            model_path = ROOT/artifact['path'].replace('\\','/')
            if sha(model_path) != artifact['sha256']:
                raise ValueError('Model checksum mismatch')
            self.models[name] = joblib.load(model_path)
        portable = ROOT/'runtime/metadata.json'
        self.portable = portable.exists()
        if self.portable:
            metadata = json.loads(portable.read_text(encoding='utf-8'))
            self.options = metadata['options']
            self.example = metadata['example']
            self.example_image = ROOT/'runtime/example.png'
        else:
            train = load_frame('A','train')
            self.options = {k:sorted(train[k].astype(str).unique().tolist()) for k in ['category','color','fabric','retail']}
            example_row = pd.read_csv(ROOT/'outputs/visuelle_embeddings/example_launch.csv',dtype={'retail':'string'}).iloc[0]
            self.example = example_row[FEATURE_INPUTS].astype(str).to_dict()
            self.example_image = (RAW/example_row.image_path).resolve()
            assert self.example_image.is_relative_to(RAW.resolve())
        self.encoder = None
        self.lock = threading.Lock()

    def metadata(self):
        return {'name':'FashionPulse AI', 'status':'hosted_academic_prototype' if os.environ.get('AWS_LAMBDA_FUNCTION_NAME') else 'local_academic_prototype',
            'choices':self.selection['choices'],'options':self.options,'example':self.example,
            'horizon_weeks':12,'variant':'A','training_cutoff':'2018-07-01',
            'evaluation':self.final['metrics'],
            'scope':'VISUELLE2 histórico. No validado para ventas actuales en Colombia.',
            'excluded_inputs':['price','audience'],
            'image_required':{k:'images' in v for k,v in self.selection['choices'].items()}}

    def predict(self, payload):
        if not isinstance(payload,dict):
            raise ValueError('Se requiere un objeto JSON.')
        allowed = set(FEATURE_INPUTS)|{'objective','image_base64'}
        if set(payload)-allowed:
            raise ValueError('Campos no admitidos: '+', '.join(sorted(set(payload)-allowed)))
        objective = payload.get('objective','weekly_mae')
        if not isinstance(objective,str) or objective not in self.selection['choices']:
            raise ValueError('Objetivo no válido.')
        for key in FEATURE_INPUTS:
            if not isinstance(payload.get(key),str) or not payload[key].strip() or len(payload[key])>100:
                raise ValueError(f'Campo requerido o no válido: {key}')
        fields = {key:payload[key].strip() for key in FEATURE_INPUTS}
        if not re.fullmatch(r'\d{4}-\d{2}-\d{2}',fields['release_date']):
            raise ValueError('La fecha debe usar AAAA-MM-DD.')
        try:
            launch = date.fromisoformat(fields['release_date'])
        except ValueError as exc:
            raise ValueError('Fecha de lanzamiento no válida.') from exc
        if not 2016 <= launch.year <= 2100:
            raise ValueError('Usa un año entre 2016 y 2100.')
        if not re.fullmatch(r'(AW|SS)\d{2}',fields['season']):
            raise ValueError('Temporada no válida; usa AW18 o SS18, por ejemplo.')
        if fields['category'] not in self.options['category']:
            raise ValueError('La categoría no está representada en el entrenamiento.')
        warnings = []
        for key in ['color','fabric','retail']:
            if fields[key] not in self.options[key]:
                warnings.append(f'Valor de {key} no visto en entrenamiento: {fields[key]}.')
        if launch.year not in {2018,2019}:
            warnings.append('Fecha fuera de los años evaluados. Resultado exploratorio, sin validación para ese periodo.')
        name = self.selection['choices'][objective]
        frame = pd.DataFrame([fields])
        with self.lock:
            if 'images' in name:
                vector = self.encode_image(payload.get('image_base64'))
                prediction = self.models[name].predict(frame,vector)[0]
                used = FEATURE_INPUTS+['image']
            else:
                prediction = self.models[name].predict(frame)[0]
                used = ['category'] if name=='category_median' else FEATURE_INPUTS
        if not np.isfinite(prediction).all():
            raise RuntimeError('Nonfinite prediction')
        if (prediction<0).any():
            warnings.append('El modelo conserva valores negativos del dataset; no equivalen necesariamente a demanda física.')
        weekly = [{'week':i+1,'start_date':str(launch+timedelta(days=7*i)),
            'end_date':str(launch+timedelta(days=7*i+6)), 'units':float(v)} for i,v in enumerate(prediction)]
        return {'objective':objective,'model':name,'variant':'A','forecast':weekly,
            'total_12weeks':float(prediction.sum()),'used_features':used,'warnings':warnings,
            'image_used':'image' in used,'training_cutoff':'2018-07-01',
            'scope':'Pronóstico académico con datos históricos VISUELLE2. No mide probabilidad de éxito ni prioridad de promoción.'}

    def encode_image(self, encoded):
        if not isinstance(encoded,str) or len(encoded)>12_000_000:
            raise ValueError('Este modelo requiere una imagen PNG o JPEG de hasta 8 MB.')
        try:
            raw = base64.b64decode(encoded,validate=True)
        except Exception as exc:
            raise ValueError('Imagen base64 no válida.') from exc
        if len(raw)>8_000_000:
            raise ValueError('Imagen demasiado grande.')
        from PIL import Image,ImageOps
        import torch
        try:
            with Image.open(io.BytesIO(raw)) as img:
                if img.format not in {'PNG','JPEG'} or img.width*img.height>12_000_000:
                    raise ValueError('Usa PNG/JPEG de hasta 12 megapíxeles.')
                rgb = ImageOps.exif_transpose(img).convert('RGB')
        except Exception as exc:
            raise ValueError('No se pudo leer la imagen PNG/JPEG.') from exc
        if self.encoder is None:
            from extract import encoder_from_files
            origin = ROOT/'outputs/visuelle_embeddings'
            info = json.loads((origin/'encoder.json').read_text(encoding='utf-8'))
            weights = origin/info['weights'].replace('\\','/')
            config = origin/info['config'].replace('\\','/')
            if sha(weights) != info['weights_sha256'] or sha(config) != info['config_sha256']:
                raise ValueError('Encoder checksum mismatch')
            torch.set_num_threads(int(os.environ.get('FASHIONPULSE_THREADS','4')))
            self.encoder,self.transform,_ = encoder_from_files(weights,config)
        with torch.inference_mode():
            return self.encoder(self.transform(rgb).unsqueeze(0)).numpy()
