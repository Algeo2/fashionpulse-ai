"""Loopback-only HTTP API and local adapter for the existing FashionPulse UI."""
import argparse
import json
import mimetypes
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit,unquote
from service import Predictor,ROOT

HERE = Path(__file__).resolve().parent

def make_handler(predictor):
    class Handler(BaseHTTPRequestHandler):
        def respond(self,status,body,content_type='application/json; charset=utf-8'):
            if isinstance(body,(dict,list)):
                body=json.dumps(body,ensure_ascii=False,allow_nan=False).encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type',content_type)
            self.send_header('Content-Length',str(len(body)))
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            path=unquote(urlsplit(self.path).path)
            if path=='/api/health':
                return self.respond(200,{'status':'ok','mode':'local','model_loaded':True})
            if path=='/api/metadata':
                return self.respond(200,predictor.metadata())
            if path=='/api/example-image':
                return self.respond(200,predictor.example_image.read_bytes(),'image/png')
            if path=='/api/evaluation':
                backtest=json.loads((ROOT/'outputs/visuelle_backtest/results.json').read_text(encoding='utf-8'))
                return self.respond(200,{'historical':backtest['summary'],'folds':backtest['folds'],
                    'final':predictor.final['metrics'],'selection':predictor.selection['choices']})
            if path in {'/local.js','/local.css'}:
                file=HERE/path[1:]
            else:
                base=(ROOT/'dist').resolve()
                file=(base/('index.html' if path=='/' else path.lstrip('/'))).resolve()
                if not file.is_relative_to(base) or file.suffix not in {'.html','.js','.css','.png','.jpg','.jpeg','.svg','.ico','.woff','.woff2'}:
                    return self.respond(404,{'error':'No encontrado'})
            if not file.is_file():
                return self.respond(404,{'error':'No encontrado'})
            body=file.read_bytes()
            if file.name=='index.html':
                body=body.replace(b'</head>',b'<link rel="stylesheet" href="/local.css"></head>')
                body=body.replace(b'</body>',b'<script src="/local.js"></script></body>')
            elif file.name=='app.js':
                # The hosted source stays intact; the local route does not expose the mock-analysis tool.
                body=body.replace(b'  registerWebMcpTools();',b'  // Local inference adapter owns analysis.')
            mime=mimetypes.guess_type(str(file))[0] or 'application/octet-stream'
            if file.suffix=='.js': mime='text/javascript'
            return self.respond(200,body,mime+('; charset=utf-8' if file.suffix in {'.html','.js','.css'} else ''))

        def do_POST(self):
            if urlsplit(self.path).path!='/api/predict':
                return self.respond(404,{'error':'No encontrado'})
            port=self.server.server_address[1]
            origin=self.headers.get('Origin')
            if origin and origin not in {f'http://127.0.0.1:{port}',f'http://localhost:{port}'}:
                return self.respond(403,{'error':'Origen no permitido'})
            if self.headers.get('Content-Type','').split(';')[0].strip()!='application/json':
                return self.respond(415,{'error':'Usa application/json'})
            try:
                size=int(self.headers.get('Content-Length','0'))
                if not 0<size<=12_100_000:
                    return self.respond(413,{'error':'Solicitud vacía o demasiado grande'})
                def reject_constant(value):
                    raise ValueError('Número JSON no válido')
                payload=json.loads(self.rfile.read(size).decode('utf-8'),parse_constant=reject_constant)
                result=predictor.predict(payload)
                return self.respond(200,result)
            except (ValueError,UnicodeError) as exc:
                return self.respond(400,{'error':str(exc)})
            except Exception:
                return self.respond(500,{'error':'No se pudo generar el pronóstico. Revisa el modelo local.'})
    return Handler

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--port',type=int,default=8765)
    args=parser.parse_args()
    predictor=Predictor()
    server=ThreadingHTTPServer(('127.0.0.1',args.port),make_handler(predictor))
    print(f'FashionPulse local: http://127.0.0.1:{server.server_address[1]}/#analizar',flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()

if __name__=='__main__': main()
