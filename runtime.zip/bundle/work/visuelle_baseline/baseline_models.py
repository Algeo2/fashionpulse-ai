"""Cold-start baselines without images, product identity or future sales."""
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

TARGETS = [str(i) for i in range(12)]
FEATURE_INPUTS = ["category", "color", "fabric", "retail", "season", "release_date"]
CAT = ["category", "color", "fabric", "retail", "collection"]
NUM = ["launch_year", "month_sin", "month_cos"]


class LaunchFeatures(BaseEstimator, TransformerMixin):
    def fit(self, X, y=None):
        self.transform(X)
        return self

    def transform(self, X):
        missing = set(FEATURE_INPUTS) - set(X.columns)
        if missing:
            raise ValueError(f"Missing launch descriptors: {sorted(missing)}")
        date = pd.to_datetime(X.release_date, errors="raise")
        if date.isna().any():
            raise ValueError("Missing launch date")
        result = pd.DataFrame(index=X.index)
        for c in CAT[:-1]:
            result[c] = X[c].astype("string").fillna("UNKNOWN").str.strip().astype(str)
        result["collection"] = X.season.astype("string").str.extract(r"^(AW|SS)", expand=False).fillna("UNKNOWN").astype(str)
        result["launch_year"] = date.dt.year.astype(float)
        result["month_sin"] = np.sin(2*np.pi*(date.dt.month-1)/12)
        result["month_cos"] = np.cos(2*np.pi*(date.dt.month-1)/12)
        return result


class CategoryCurve(BaseEstimator):
    def __init__(self, statistic="mean"):
        self.statistic = statistic

    def fit(self, X, y):
        if self.statistic not in {"mean", "median"}:
            raise ValueError("Unknown statistic")
        target = pd.DataFrame(np.asarray(y, dtype=float), columns=TARGETS)
        target["category"] = X.category.astype(str).to_numpy()
        self.curves_ = getattr(target.groupby("category")[TARGETS], self.statistic)()
        self.fallback_ = getattr(np, self.statistic)(np.asarray(y, dtype=float), axis=0)
        return self

    def predict(self, X):
        frame = self.curves_.reindex(X.category.astype(str)).copy()
        return frame.fillna(dict(zip(TARGETS, self.fallback_))).to_numpy(dtype=float)


class ZeroCurve(BaseEstimator):
    def fit(self, X, y):
        return self

    def predict(self, X):
        return np.zeros((len(X), 12), dtype=float)


def make_model(name):
    if name == "category_mean":
        return CategoryCurve("mean")
    if name == "category_median":
        return CategoryCurve("median")
    if name == "zero_control":
        return ZeroCurve()
    leaf = {"extra_trees_leaf20": 20, "extra_trees_leaf60": 60}[name]
    return Pipeline([
        ("launch", LaunchFeatures()),
        ("encode", ColumnTransformer([
            ("categorical", OneHotEncoder(handle_unknown="ignore", sparse_output=False, dtype=np.float32), CAT),
            ("numeric", "passthrough", NUM)])),
        ("model", ExtraTreesRegressor(n_estimators=96, max_depth=14, min_samples_leaf=leaf,
            max_features=0.75, random_state=42, n_jobs=4))])


def metrics(y, pred, products):
    y, pred = np.asarray(y, dtype=float), np.asarray(pred, dtype=float)
    if y.shape != pred.shape or y.ndim != 2 or y.shape[1] != 12:
        raise ValueError("Expected matching (samples, 12) targets and predictions")
    if not np.isfinite(y).all() or not np.isfinite(pred).all():
        raise ValueError("Nonfinite target or prediction")
    err = pred-y
    absolute = np.abs(err)
    denom = np.abs(y).sum()
    per_product = pd.DataFrame({"id": np.asarray(products), "mae": absolute.mean(axis=1)}).groupby("id").mae.mean()
    return {"mae": float(absolute.mean()), "rmse": float(np.sqrt(np.mean(err**2))),
        "wape_pct": float(100*absolute.sum()/denom) if denom else None,
        "bias": float(err.mean()), "macro_product_mae": float(per_product.mean()),
        "mae_total_12weeks": float(np.abs(err.sum(axis=1)).mean()),
        "observed_total": float(y.sum()), "predicted_total": float(pred.sum())}
